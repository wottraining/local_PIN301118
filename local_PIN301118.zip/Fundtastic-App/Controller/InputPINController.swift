//
//  InputPINController.swift
//  Fundtastic-App
//
//  Created by Macintosh on 28/11/18.
//  Copyright © 2018 Macintosh. All rights reserved.
//

import UIKit

class InputPINController: UIViewController {

    @IBOutlet var circle1: UIImageView!
    @IBOutlet var circle2: UIImageView!
    @IBOutlet var circle3: UIImageView!
    @IBOutlet var circle4: UIImageView!
    @IBOutlet var circle5: UIImageView!
    @IBOutlet var circle6: UIImageView!
    
    let darkCircle = UIImage(named: "Ellipse_144.png")
    let frameCircle = UIImage(named: "Ellipse_145.png")
    let defaultUser = UserDefaults.standard
    
    var listPIN = [Int()]
    var pinNumber = ""
    var savePIN = ""
    var images = [UIImageView()]
    var indexImageView = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        savePIN = defaultUser.string(forKey: "PIN")!
        print("savePIN at inputPIN: \(savePIN)")
        showToast(message: "Save PIN success!")
        clearCircle()
        cleaner()
    }
    
    @IBAction func delBtnPress(_ sender: Any) {
        clearCircle()
        cleaner()
    }
    
    @IBAction func backBtnPress(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    @IBAction func keyBtnPress(keyBtn: UIButton) {
        
        images[indexImageView].image = darkCircle
        
        if listPIN.count < 6 {
            listPIN.append(keyBtn.tag)
            indexImageView = indexImageView + 1
            print("PIN count: \(indexImageView)")
            
            if listPIN.count == 6 {
                
                for value in listPIN {
                    pinNumber += "\(value)"
                }

                confirmPIN()
            }
        }
    }
    
    func confirmPIN() {
        if pinNumber != "" {
            if pinNumber.elementsEqual(savePIN) {
                
                
                movetoSegue()
                performSegue(withIdentifier: "mainMenu", sender: savePIN)
            } else {
                showToast(message: "Confirm PIN failed!")
                
                clearCircle()
                cleaner()
            }
        } else {
            print("error pinNumber null")
        }
    }
    func movetoSegue() {
        clearCircle()
        cleaner()
        
    }
    
    func prepareCircle() {
        images.removeAll(keepingCapacity: false)
        images.append(circle1)
        images.append(circle2)
        images.append(circle3)
        images.append(circle4)
        images.append(circle5)
        images.append(circle6)
    }
    func clearCircle() {
        prepareCircle()
        for x in 0...(images.count - 1) {
            images[x].image = frameCircle
        }
        
    }
    func cleaner() {
        indexImageView = 0
        pinNumber = ""
        listPIN.removeAll(keepingCapacity: false)
    }
    
    func showToast(message : String) {
        
        let viewFrame = view.frame
        let toastLabel = UILabel(frame: CGRect(x: viewFrame.size.width/2 - 75, y: viewFrame.size.height-100, width: 200, height: 35))
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastLabel.textColor = UIColor.white
        toastLabel.textAlignment = .center;
        toastLabel.font = UIFont(name: "Montserrat-Light", size: 12.0)
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 14;
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 6.0, delay: 0.1, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    }

}
