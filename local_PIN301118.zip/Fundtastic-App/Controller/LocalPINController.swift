//
//  LocalPINController.swift
//  Fundtastic-App
//
//  Created by Macintosh on 26/11/18.
//  Copyright © 2018 Macintosh. All rights reserved.
//

import UIKit

class LocalPINController: UIViewController {
    
    @IBOutlet var circle1: UIImageView!
    @IBOutlet var circle2: UIImageView!
    @IBOutlet var circle3: UIImageView!
    @IBOutlet var circle4: UIImageView!
    @IBOutlet var circle5: UIImageView!
    @IBOutlet var circle6: UIImageView!
    
    @IBOutlet weak var headerLbl: UILabel!
    @IBOutlet weak var tittleLbl: UILabel!
    
    let tittle1 = "Buat 6 angka PIN untuk masuk ke aplikasi FUNDtastic di perangkat ini."
    let header1 = "BUAT PIN MASUK"
    let tittle2 = "Masukan kembali 6 angka untuk konfirmasi."
    let header2 = "KONFIRMASI PIN"
    let darkCircle = UIImage(named: "Ellipse_dot-1.png")
    let frameCircle = UIImage(named: "frame.png")
    let defaultUser = UserDefaults.standard
    
    var listPIN = [Int()]
    var pinNumber = ""
    var savePIN = ""
    var images = [UIImageView()]
    var indexImageView = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        defaultUser.set(false, forKey: "setUpKey")
        clearCircle()
        cleaner()
        
        if headerLbl.text == "" || tittleLbl.text == "" {
            headerLbl.text = header1
            tittleLbl.text = tittle1
        }
        
    }
    
    
    @IBAction func keyBtnPress(keyBtn: UIButton) {
        
        images[indexImageView].image = darkCircle
        
        if listPIN.count < 6 {
            listPIN.append(keyBtn.tag)
            indexImageView = indexImageView + 1
            print("PIN count: \(indexImageView)")
            
            if listPIN.count == 6 {
                headerLbl.text = header2
                tittleLbl.text = tittle2
                
                for value in listPIN {
                    pinNumber += "\(value)"
                }
                
                if savePIN.count < 6 {
                    clearCircle()
                    savePIN = pinNumber
                    
                    cleaner()
                    
                    print("savePIN: \(savePIN)")
                    print("pinNumber: \(pinNumber)")
                    
                } else {
                    print("savePIN: \(savePIN)")
                    print("pinNumber: \(pinNumber)")
                    
                    confirmPIN()
                }
            }
        }
    }
    
    @IBAction func delBtnPress(_ sender: Any) {
        clearCircle()
        cleaner()
    }
    
    @IBAction func backBtnPress(_ sender: UIButton) {
        //dismiss(animated: true, completion: nil)
        if savePIN != "" {
            movetoSegue()
            savePIN = ""
        }
        else {
            performSegue(withIdentifier: "mainMenu", sender: nil)
            
        }
    }
    
    func movetoSegue() {
        clearCircle()
        cleaner()
        
        headerLbl.text = header1
        tittleLbl.text = tittle1
        
    }
    func confirmPIN() {
        if pinNumber != "" {
            if pinNumber.elementsEqual(savePIN) {
                
                //print("login success... (1)")
                defaultUser.set(true, forKey: "setUpKey")
                defaultUser.set(savePIN, forKey: "PIN")
                movetoSegue()
                performSegue(withIdentifier: "mainMenu", sender: nil)
            } else {
                showToast(message: "Confirm PIN failed")
                //showToast(message: tittle2)
                //print("Confirm PIN failed!")
                
                clearCircle()
                cleaner()
            }
        } else {
            print("error pinNumber null")
        }
    }
    func prepareCircle() {
        images.removeAll(keepingCapacity: false)
        images.append(circle1)
        images.append(circle2)
        images.append(circle3)
        images.append(circle4)
        images.append(circle5)
        images.append(circle6)
    }
    func clearCircle() {
        prepareCircle()
        for x in 0...(images.count - 1) {
            images[x].image = frameCircle
        }
        
    }
    func cleaner() {
        indexImageView = 0
        pinNumber = ""
        listPIN.removeAll(keepingCapacity: false)
    }
    
    func showToast(message : String) {

        let viewFrame = view.frame
        let toastLabel = UILabel(frame: CGRect(x: viewFrame.size.width/2 - 75, y: viewFrame.size.height-100, width: 200, height: 35))
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastLabel.textColor = UIColor.white
        toastLabel.textAlignment = .center;
        toastLabel.font = UIFont(name: "Montserrat-Light", size: 12.0)
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 14;
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 6.0, delay: 0.1, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    }

}
