//
//  ViewController.swift
//  Fundtastic-App
//
//  Created by Macintosh on 26/11/18.
//  Copyright © 2018 Macintosh. All rights reserved.
//

import UIKit

class LoginController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        password.delegate = self
        username.clearsOnBeginEditing = true
        password.clearsOnBeginEditing = true
    }

    @IBAction func loginPress(_ sender: UIButton) {
//        let tittleLbl = "Buat 6 angka PIN untuk masuk ke aplikasi FUNDtastic di perangkat ini."
//        let headerLbl = "BUAT PIN MASUK"
//        let letlabelMap:[String: String] = ["head": headerLbl,"tittle": tittleLbl]
        
        if username.text == "admin" && password.text == "admin" {
            performSegue(withIdentifier: "localpin", sender: nil)
            print("login success...")
            username.text = ""
            password.text = ""
            
        } else {
            seeker()
            password.text = ""
        }
            
    }
    
    func seeker() {
        
        password.resignFirstResponder()
        
        UIView.animate(withDuration: 0.1, delay: 0.0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: UIView.AnimationOptions.curveEaseIn, animations: {
            self.password.center.x -= 20
        }, completion: nil)
        
        UIView.animate(withDuration: 0.1, delay: 0.1, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: UIView.AnimationOptions.curveEaseIn, animations: {
            self.password.center.x += 20
        }, completion: nil)
        
        UIView.animate(withDuration: 0.1, delay: 0.2, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: UIView.AnimationOptions.curveEaseIn, animations: {
            self.password.center.x -= 20
        }, completion: nil)
        
        UIView.animate(withDuration: 0.1, delay: 0.3, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: UIView.AnimationOptions.curveEaseIn, animations: {
            self.password.center.x += 20
        }, completion: nil)
    }
    
}

