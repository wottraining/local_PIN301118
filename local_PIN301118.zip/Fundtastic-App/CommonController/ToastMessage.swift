//
//  ToastMessage.swift
//  Fundtastic-App
//
//  Created by Macintosh on 29/11/18.
//  Copyright © 2018 Macintosh. All rights reserved.
//

import UIKit

class ToastMessage: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    

}
